//#ifndef MOBAGEN_SCRIPT_H
//#define MOBAGEN_SCRIPT_H
//
//#include <quickjspp.hpp>
//
// class Script {
//
//};
//
//#endif  // MOBAGEN_SCRIPT_H
