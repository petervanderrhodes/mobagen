#ifndef MOBAGEN_SENDMESSAGEOPTIONS_H
#define MOBAGEN_SENDMESSAGEOPTIONS_H

enum class SendMessageOptions : bool {
  RequireReceiver,
  DontRequireReceiver,
};
#endif  // MOBAGEN_SENDMESSAGEOPTIONS_H
