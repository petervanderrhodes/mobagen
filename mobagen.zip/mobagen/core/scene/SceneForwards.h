#ifndef MOBAGEN_ENGINE_SCENEFORWARDS_H_
#define MOBAGEN_ENGINE_SCENEFORWARDS_H_

class Object;
class Component;
class GameObject;
class Scene;
class Transform;
class ScriptableObject;

#endif