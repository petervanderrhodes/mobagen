#include "JohnConway.h"

// Reference: https://playgameoflife.com/info
void JohnConway::Step(World& world) {

}

int JohnConway::CountNeighbors(World& world, Point2D point) {

}
