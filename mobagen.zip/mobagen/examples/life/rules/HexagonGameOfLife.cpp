//
// Created by atolstenko on 2/9/2023.
//

#include "HexagonGameOfLife.h"
void HexagonGameOfLife::Step(World& world) {

}
int HexagonGameOfLife::CountNeighbors(World& world, Point2D point) {
  return 0;
}
